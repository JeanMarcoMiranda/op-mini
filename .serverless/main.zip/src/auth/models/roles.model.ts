export enum Role {
  STOCKER = 'Almacenero',
  ADMIN = 'Administrador',
}